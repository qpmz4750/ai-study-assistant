"""Pydantic API models."""

